package net.anticrash.mixin;

import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen; // Mojang's name for Yarn's "HandledScreen"
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * GUARD #1's live hook point, renamed to Mojang's class name
 * (AbstractContainerScreen instead of Yarn's HandledScreen). Left as a
 * documented require=0 no-op — verify the real "draw item tooltip" method
 * name on this class in your 26.3 dev environment (it took an ItemStack
 * and mouse position in every mapping set I'm aware of) and update
 * `method = "..."` below, then wire in NbtDepthGuard as described in the
 * comment inside the method body.
 */
@Mixin(AbstractContainerScreen.class)
public abstract class HandledScreenTooltipMixin {

    private static final Logger LOGGER = LoggerFactory.getLogger("anticrash");

    // Placeholder target — verify/rename against 26.3's actual class.
    @Inject(method = "renderTooltip", at = @At("HEAD"), cancellable = true, require = 0)
    private void anticrash$guardTooltip(CallbackInfo ci) {
        // Real wiring: pull the ItemStack local/parameter from this
        // injection point, adapt its custom-data root to
        // NbtDepthGuard.Node, and do:
        //
        //   if (!NbtDepthGuard.isSafeToWalk(adaptedRoot)) {
        //       LOGGER.warn("[AntiCrash] Skipped rendering a tooltip with " +
        //               "suspiciously deep/large NBT (possible crash attempt).");
        //       ci.cancel();
        //   }
    }
}
