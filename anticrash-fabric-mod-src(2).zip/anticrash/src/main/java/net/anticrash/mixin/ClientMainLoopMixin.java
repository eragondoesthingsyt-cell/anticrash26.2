package net.anticrash.mixin;

import net.minecraft.client.Minecraft; // Mojang's name for what Yarn called "MinecraftClient"
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Scaffold for guard #14's live hook point on the game's per-frame method.
 * Left as a documented require=0 no-op — see CrashGuard's Javadoc for why
 * a plain @Inject can't fully wrap this method's body (you'd want
 * Mixin Extras' @WrapOperation for that), and see the README for how to
 * finish this once you're looking at 26.3's actual decompiled source.
 *
 * Renamed from the Yarn-mapped `render(boolean)` to Mojang's class name;
 * the equivalent per-frame method has historically been named `run()` or
 * `runTick(boolean)` in official mappings depending on version — verify
 * the real name/descriptor for 26.3 in your IDE and update `method = "..."`
 * below (or delete this file if you'd rather skip guard #14's global net
 * and rely on guards #1-#13's targeted checks only).
 */
@Mixin(Minecraft.class)
public abstract class ClientMainLoopMixin {

    @Inject(method = "runTick", at = @At("HEAD"), cancellable = true, require = 0)
    private void anticrash$guardRender(CallbackInfo ci) {
        // See class Javadoc — intentionally left as a no-op scaffold.
    }
}
