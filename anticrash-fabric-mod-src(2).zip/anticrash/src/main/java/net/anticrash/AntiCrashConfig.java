package net.anticrash;

/**
 * Central tunables for every guard. Kept as plain static fields (no config
 * library dependency) so the mod has zero extra deps to go wrong on a
 * brand-new game version. Wire this up to Mod Menu / Cloth Config later if
 * you want in-game sliders.
 */
public final class AntiCrashConfig {

    private AntiCrashConfig() {}

    // #1 NBT depth/size (tooltips, item data)
    public static final int MAX_NBT_DEPTH = 64;
    public static final int MAX_NBT_LIST_SIZE = 4096;

    // #2 Written book
    public static final int MAX_BOOK_PAGE_CHARS = 4096;
    public static final int MAX_BOOK_PAGES = 256;

    // #3 Sign text
    public static final int MAX_SIGN_LINE_CHARS = 384;

    // #4 Anvil rename
    public static final int MAX_ANVIL_NAME_CHARS = 128;

    // #5 / #6 Chat & title text components
    public static final int MAX_TEXT_COMPONENT_DEPTH = 48;
    public static final int MAX_TEXT_COMPONENT_SIBLINGS = 2048;

    // #7 Firework explosions
    public static final int MAX_FIREWORK_EXPLOSIONS = 64;

    // #8 Potion / enchantment id + level sanity
    public static final int MAX_EFFECT_AMPLIFIER = 255;
    public static final int MAX_ENCHANTMENT_LEVEL = 255;

    // #9 Map data
    public static final int MAP_EXPECTED_LENGTH = 128 * 128;

    // #10 Skull / player-head profile textures
    public static final int MAX_TEXTURE_VALUE_BASE64_CHARS = 20000;

    // #11 Entity metadata
    public static final boolean ISOLATE_ENTITY_TRACKER_ERRORS = true;

    // #12 Custom payload / plugin channels
    public static final int MAX_CUSTOM_PAYLOAD_BYTES = 1 << 20; // 1 MiB

    // #13 Position / coordinate sanity
    public static final double MAX_COORDINATE = 3.0E7; // vanilla world border hard limit is ~3.0E7

    // #14 Global render/tick safety net + packet flood
    public static final int MAX_PACKETS_PER_TICK_PER_CHANNEL = 200;
}
