package net.anticrash;

import net.anticrash.guard.PayloadGuard;
import net.anticrash.guard.TextComponentGuard;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.network.chat.Component; // Mojang's name for what Yarn called "Text"
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Entry point. Wires up the guards that only need Fabric API's stable,
 * documented events — no risky mixin targets needed for these three.
 *
 * Guards #1-#4, #7-#11, #13 are pure utility classes under
 * net.anticrash.guard; call them from wherever your build reads the
 * relevant untrusted data (see the Javadoc on each guard class and the
 * README for exact call-site guidance).
 */
public class AntiCrashMod implements ClientModInitializer {

    public static final Logger LOGGER = LoggerFactory.getLogger("anticrash");

    @Override
    public void onInitializeClient() {
        LOGGER.info("[AntiCrash] Loading — guarding against 14 known client-crash vectors.");

        // Guard #12 support: clear per-tick packet-flood counters every tick.
        ClientTickEvents.END_CLIENT_TICK.register(client -> PayloadGuard.resetPerTickCounters());

        // Guards #5/#6: reject chat/system messages whose Text tree is
        // deep/wide enough to be a deliberate render-hang attempt, before
        // the client ever tries to flatten it into a chat line.
        ClientReceiveMessageEvents.ALLOW_CHAT.register((message, signedMessage, sender, params, receptionTimestamp) ->
                guardIncomingText(message, "chat"));

        ClientReceiveMessageEvents.ALLOW_GAME.register((message, overlay) ->
                guardIncomingText(message, overlay ? "actionbar" : "system"));

        LOGGER.info("[AntiCrash] Ready.");
    }

    private static boolean guardIncomingText(Component message, String source) {
        boolean safe = TextComponentGuard.isSafeToFlatten(new SiblingAdapter(message));
        if (!safe) {
            LOGGER.warn("[AntiCrash] Dropped an incoming {} message: its text-component tree " +
                    "exceeded safe depth/width (likely a crash attempt), refusing to render it.", source);
        }
        return safe;
    }

    /**
     * Adapts Component#getSiblings() to TextComponentGuard's generic Node
     * contract. getSiblings() has kept that exact name across both Yarn and
     * Mojang mappings historically, but double-check it still exists on
     * Component in 26.3 if this fails to compile — it's the one method
     * this whole file actually depends on existing.
     */
    private static final class SiblingAdapter implements TextComponentGuard.Node {
        private final List<Component> siblings;

        SiblingAdapter(Component text) {
            this.siblings = text.getSiblings();
        }

        @Override
        public int siblingCount() {
            return siblings.size();
        }

        @Override
        public TextComponentGuard.Node sibling(int index) {
            return new SiblingAdapter(siblings.get(index));
        }
    }
}
