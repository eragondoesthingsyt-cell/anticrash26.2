package net.anticrash.guard;

import net.anticrash.AntiCrashConfig;

/**
 * GUARD #7 — firework rockets with a hand-edited NBT explosion list
 * containing hundreds/thousands of "explosion" entries. Vanilla spawns one
 * particle burst per entry; an absurd count either OOMs the particle
 * system or tanks the frame rate hard enough to look like a crash/hang.
 *
 * Wire in wherever the explosion list length is read before spawning
 * particles (client-side firework rendering / EntityFireworkRocket-ish
 * class in your snapshot).
 */
public final class FireworkGuard {

    private FireworkGuard() {}

    /** Returns the clamped count you should actually spawn effects for. */
    public static int clampExplosionCount(int rawCount) {
        if (rawCount < 0) return 0;
        return Math.min(rawCount, AntiCrashConfig.MAX_FIREWORK_EXPLOSIONS);
    }
}
