package net.anticrash.guard;

import net.anticrash.AntiCrashConfig;

/**
 * GUARD #8 — malformed potion effect / enchantment payloads: an amplifier
 * or enchantment level sent as e.g. Integer.MAX_VALUE, or a registry id
 * pointing outside the valid table, can throw ArrayIndexOutOfBounds deep in
 * rendering (screen overlay icons) or in attribute-modifier math.
 *
 * Wire in wherever the client applies an incoming StatusEffectInstance /
 * enchantment level from a packet, before it's used to index anything.
 */
public final class EffectGuard {

    private EffectGuard() {}

    public static int clampAmplifier(int rawAmplifier) {
        if (rawAmplifier < 0) return 0;
        return Math.min(rawAmplifier, AntiCrashConfig.MAX_EFFECT_AMPLIFIER);
    }

    public static int clampEnchantmentLevel(int rawLevel) {
        if (rawLevel < 0) return 0;
        return Math.min(rawLevel, AntiCrashConfig.MAX_ENCHANTMENT_LEVEL);
    }

    /** Generic bounds check for any "registry id must be within [0, size)" case. */
    public static boolean isRegistryIdInRange(int id, int registrySize) {
        return id >= 0 && id < registrySize;
    }
}
