package net.anticrash.guard;

import net.anticrash.AntiCrashConfig;
import java.util.Base64;

/**
 * GUARD #10 — malicious player-head / skull item profile textures. A
 * hand-edited "textures" property with garbage or oversized base64 data
 * throws mid-decode while the client tries to fetch/parse the skin, which
 * some code paths don't catch cleanly.
 */
public final class SkullTextureGuard {

    private SkullTextureGuard() {}

    public static boolean isTextureValueSafe(String base64Value) {
        if (base64Value == null) return false;
        if (base64Value.length() > AntiCrashConfig.MAX_TEXTURE_VALUE_BASE64_CHARS) return false;
        try {
            Base64.getDecoder().decode(base64Value);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }
}
