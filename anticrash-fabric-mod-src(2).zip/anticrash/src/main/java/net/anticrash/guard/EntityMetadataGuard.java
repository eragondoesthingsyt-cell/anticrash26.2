package net.anticrash.guard;

import net.anticrash.AntiCrashConfig;
import java.util.function.IntConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * GUARD #11 — one entity with malformed tracked-data (an out-of-range enum
 * index, bad pose id, etc.) throwing inside the shared entity-tracker
 * update loop, which without isolation kills every entity update for that
 * tick (visible as mass entity desync or a hard crash).
 *
 * Wrap each individual entity's metadata-apply call with
 * {@link #applyIsolated}: one bad entity gets skipped and logged instead of
 * bringing down the whole tracker pass.
 */
public final class EntityMetadataGuard {

    private static final Logger LOGGER = LoggerFactory.getLogger("anticrash");

    private EntityMetadataGuard() {}

    public static void applyIsolated(int entityId, IntConsumer applyFn) {
        if (!AntiCrashConfig.ISOLATE_ENTITY_TRACKER_ERRORS) {
            applyFn.accept(entityId);
            return;
        }
        try {
            applyFn.accept(entityId);
        } catch (Throwable t) {
            LOGGER.warn("[AntiCrash] Suppressed malformed entity-metadata update for entity {}: {}",
                    entityId, t.toString());
        }
    }
}
