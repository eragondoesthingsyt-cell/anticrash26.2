package net.anticrash.guard;

import net.anticrash.AntiCrashConfig;

/**
 * GUARDS #5, #6 — malicious chat / title / subtitle JSON text components.
 * A crafted hover-event / sibling chain that's thousands of components deep
 * (or has thousands of siblings at one level) causes a StackOverflowError
 * or a multi-second freeze when the client flattens it for rendering.
 *
 * Same pattern as NbtDepthGuard: adapt the sibling list to this Node
 * interface at the call site (net.minecraft.network.chat.Component —
 * Mojang's name for what Yarn called Text, already used this way in
 * AntiCrashMod — has had a getSiblings()-style accessor across every
 * modern version).
 */
public final class TextComponentGuard {

    private TextComponentGuard() {}

    public interface Node {
        int siblingCount();
        Node sibling(int index);
    }

    public static boolean isSafeToFlatten(Node root) {
        return walk(root, 0);
    }

    private static boolean walk(Node node, int depth) {
        if (node == null) return true;
        if (depth > AntiCrashConfig.MAX_TEXT_COMPONENT_DEPTH) return false;
        int count = node.siblingCount();
        if (count > AntiCrashConfig.MAX_TEXT_COMPONENT_SIBLINGS) return false;
        for (int i = 0; i < count; i++) {
            if (!walk(node.sibling(i), depth + 1)) return false;
        }
        return true;
    }
}
