package net.anticrash.guard;

import net.anticrash.AntiCrashConfig;

/**
 * GUARD #13 — NaN / Infinity / absurd-magnitude position updates. A
 * teleport or entity-move packet with a NaN or huge coordinate propagates
 * into physics and chunk-section math, which throws or hangs trying to
 * allocate/index based on it. Reject before applying.
 */
public final class CoordinateGuard {

    private CoordinateGuard() {}

    public static boolean isSafe(double x, double y, double z) {
        return isFinite(x) && isFinite(y) && isFinite(z)
                && Math.abs(x) <= AntiCrashConfig.MAX_COORDINATE
                && Math.abs(y) <= AntiCrashConfig.MAX_COORDINATE
                && Math.abs(z) <= AntiCrashConfig.MAX_COORDINATE;
    }

    private static boolean isFinite(double v) {
        return !Double.isNaN(v) && !Double.isInfinite(v);
    }
}
