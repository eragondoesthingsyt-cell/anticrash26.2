package net.anticrash.guard;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * GUARD #14 — the last line of defense. Every other guard prevents a
 * specific bad input from ever reaching risky code. This one assumes some
 * *other*, unknown-to-us crash vector slips through anyway, and stops an
 * uncaught exception on the render or tick pass from taking the whole game
 * down to the crash screen: log it, skip that one frame/tick, keep going.
 *
 * This deliberately does NOT swallow OutOfMemoryError or StackOverflowError
 * — those mean the JVM/thread state may already be unreliable, and pretending
 * to recover from them can do more harm (corrupted state, silent data loss)
 * than a clean crash-and-restart would.
 */
public final class CrashGuard {

    private static final Logger LOGGER = LoggerFactory.getLogger("anticrash");

    private CrashGuard() {}

    public interface UnsafeRunnable {
        void run() throws Throwable;
    }

    public static void protect(String label, UnsafeRunnable action) {
        try {
            action.run();
        } catch (OutOfMemoryError | StackOverflowError fatal) {
            throw fatal; // don't pretend to recover from these
        } catch (Throwable t) {
            LOGGER.error("[AntiCrash] Caught an exception in '{}' that would otherwise have crashed the game. " +
                    "Skipping this frame/tick instead.", label, t);
        }
    }
}
