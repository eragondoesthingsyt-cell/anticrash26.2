package net.anticrash.guard;

import net.anticrash.AntiCrashConfig;
import java.util.HashMap;
import java.util.Map;

/**
 * GUARD #12 — oversized or flooded custom payload (plugin channel)
 * packets. A rogue server can send a channel packet with a huge byte
 * buffer (blowing up allocation) or spam thousands of packets on one
 * channel per tick (choking the network thread / client). Cap both.
 *
 * Call {@link #isSizeSafe} before reading a custom-payload buffer, and
 * call {@link #allowAndCount} once per received packet on that channel to
 * rate-limit; reset counts every client tick via
 * {@link #resetPerTickCounters()} (already wired into AntiCrashMod's tick
 * handler).
 */
public final class PayloadGuard {

    private PayloadGuard() {}

    private static final Map<String, Integer> COUNTS = new HashMap<>();

    public static boolean isSizeSafe(int byteLength) {
        return byteLength >= 0 && byteLength <= AntiCrashConfig.MAX_CUSTOM_PAYLOAD_BYTES;
    }

    public static synchronized boolean allowAndCount(String channelId) {
        int next = COUNTS.merge(channelId, 1, Integer::sum);
        return next <= AntiCrashConfig.MAX_PACKETS_PER_TICK_PER_CHANNEL;
    }

    public static synchronized void resetPerTickCounters() {
        COUNTS.clear();
    }
}
