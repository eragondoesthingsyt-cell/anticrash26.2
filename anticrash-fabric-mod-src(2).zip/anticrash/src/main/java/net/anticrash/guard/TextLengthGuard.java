package net.anticrash.guard;

import net.anticrash.AntiCrashConfig;

/**
 * GUARDS #2, #3, #4 — oversized written-book pages, sign lines, and anvil
 * rename text. A server (or a hand-crafted NBT-edited item on a compromised
 * save) can hand the client a "book" with megabytes of text per page, or a
 * sign line thousands of characters long, which chokes the font renderer /
 * text-wrapping code. Clamp before it ever reaches rendering.
 *
 * Wire these in wherever your build reads the raw string just before
 * handing it to the screen (BookScreen page setter, SignEditScreen line
 * setter, AnvilScreen name field setter — those three class names have been
 * stable in Yarn since 1.14+, exact field/method names may differ slightly
 * per snapshot; your IDE's autocomplete on the class will show you the
 * current ones in seconds).
 */
public final class TextLengthGuard {

    private TextLengthGuard() {}

    public static String clampBookPage(String raw) {
        if (raw == null) return "";
        return raw.length() > AntiCrashConfig.MAX_BOOK_PAGE_CHARS
                ? raw.substring(0, AntiCrashConfig.MAX_BOOK_PAGE_CHARS)
                : raw;
    }

    public static boolean isBookPageCountSafe(int pageCount) {
        return pageCount <= AntiCrashConfig.MAX_BOOK_PAGES;
    }

    public static String clampSignLine(String raw) {
        if (raw == null) return "";
        return raw.length() > AntiCrashConfig.MAX_SIGN_LINE_CHARS
                ? raw.substring(0, AntiCrashConfig.MAX_SIGN_LINE_CHARS)
                : raw;
    }

    public static String clampAnvilName(String raw) {
        if (raw == null) return "";
        return raw.length() > AntiCrashConfig.MAX_ANVIL_NAME_CHARS
                ? raw.substring(0, AntiCrashConfig.MAX_ANVIL_NAME_CHARS)
                : raw;
    }
}
