package net.anticrash.guard;

import net.anticrash.AntiCrashConfig;

/**
 * GUARD #9 — corrupted map-item data. A map update packet with a colors
 * array shorter than the expected 128x128 (or a bogus width/height/offset)
 * causes an ArrayIndexOutOfBounds while rendering the map texture.
 */
public final class MapGuard {

    private MapGuard() {}

    public static boolean isColorArraySafe(byte[] colors) {
        return colors != null && colors.length >= AntiCrashConfig.MAP_EXPECTED_LENGTH;
    }

    /** Bounds-checked read; returns 0 (blank pixel) instead of throwing. */
    public static byte safeGet(byte[] colors, int index) {
        if (colors == null || index < 0 || index >= colors.length) return 0;
        return colors[index];
    }
}
