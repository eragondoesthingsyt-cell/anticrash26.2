package net.anticrash.guard;

import net.anticrash.AntiCrashConfig;

/**
 * GUARD #1 — Malicious / recursive NBT on items (the classic "tooltip
 * crasher"). Deeply nested compound tags or absurdly long lists make the
 * client hang or StackOverflow when it walks the tag to build a tooltip.
 *
 * Pure logic, no Minecraft types: pass it a generic tree walker so it works
 * regardless of exactly how NbtCompound/NbtList/NbtElement look in this
 * game version. Wire it in wherever the client walks an ItemStack's custom
 * data to build a tooltip (in current Yarn history that's usually inside
 * Item#getTooltip / the tooltip-building code called from
 * AbstractContainerScreen, Mojang's name for what Yarn called HandledScreen).
 */
public final class NbtDepthGuard {

    private NbtDepthGuard() {}

    /** Simple visitor contract the caller adapts to the real NBT types. */
    public interface Node {
        int childCount();
        Node child(int index);
    }

    /**
     * Returns false (reject / stop walking) the moment depth or breadth
     * exceeds sane bounds, instead of recursing forever.
     */
    public static boolean isSafeToWalk(Node root) {
        return walk(root, 0);
    }

    private static boolean walk(Node node, int depth) {
        if (node == null) return true;
        if (depth > AntiCrashConfig.MAX_NBT_DEPTH) return false;
        int count = node.childCount();
        if (count > AntiCrashConfig.MAX_NBT_LIST_SIZE) return false;
        for (int i = 0; i < count; i++) {
            if (!walk(node.child(i), depth + 1)) return false;
        }
        return true;
    }
}
